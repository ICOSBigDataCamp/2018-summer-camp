import twitter
import oauthDance

###### How do you get "more" tweets?  Not this way!

def printTexts(tweets) :
    for tweet in tweets :
        print tweet['text']

t = oauthDance.login()

twoTweets = t.statuses.user_timeline(screen_name="UMBigData", count=2)

printTexts(twoTweets)

# By default we always get the newest tweets

sameTweets = t.statuses.user_timeline(screen_name="UMBigData", count=2)
printTexts(sameTweets)










