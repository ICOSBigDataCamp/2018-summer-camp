import twitter
import oauthDance
import json

t = oauthDance.login()
ts = twitter.TwitterStream(auth=t.auth)

# Ann Arbor Bounding Box from places lookup
# [-83.799572, 42.222668], [-83.675807, 42.222668], 
# [-83.675807, 42.323973], [-83.799572, 42.323973]
#
# For location, we use Longitude then Latitutde.
# Southern/western corner first
# Northern/eastern corner second

iterator = ts.statuses.filter(locations="-83.8,42.223,-83.676,42.324")

for tweet in iterator :
    print tweet['user']['screen_name'], '     ', tweet['text']
