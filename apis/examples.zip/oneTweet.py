import twitter
import oauthDance
import json

#########  Get one tweet from our test account

t = oauthDance.login()

#tweets = t.statuses.user_timeline(screen_name="UMBigData", count=1)
tweets = t.statuses.user_timeline(count=1, screen_name="UMBigData")

# These are always returned as a collection of tweets

#print tweets[0]
#print json.dumps(tweets[0],indent=4)
print tweets[0]['text']









