import twitter
import oauthDance
import json

###### an example of a search query based on location.

t = oauthDance.login()

print
print
print "Current St. Louis hockey mentions"
result = t.search.tweets(q="hockey place:0570f015c264cbd9")
for tweet in result['statuses'] :
    print tweet['user']['screen_name'] + '       ' + tweet['text']
    print


print
print
print "Current Dallas hockey mentions"
result = t.search.tweets(q="hockey place:18810aa5b43e76c7")
for tweet in result['statuses'] :
    print tweet['user']['screen_name'] + '       ' + tweet['text']
    print 

