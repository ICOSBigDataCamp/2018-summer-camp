import twitter
import oauthDance
import json

###### an example of a search query with time limits

t = oauthDance.login()

print "Dallas Stars mentions before May 11"
result = t.search.tweets(q="Dallas Stars until:2016-05-11")
for tweet in result['statuses'] :
    print tweet['user']['screen_name'] + '       ' + tweet['text']
    print


print
print
print "Current Dallas Stars mentions"
result = t.search.tweets(q="Dallas Stars")
for tweet in result['statuses'] :
    # print tweet['screen_name'] + '       ' + tweet['text']
    # print json.dumps(tweet, indent=4)
    print tweet['user']['screen_name'] + '       ' + tweet['text']
    print
